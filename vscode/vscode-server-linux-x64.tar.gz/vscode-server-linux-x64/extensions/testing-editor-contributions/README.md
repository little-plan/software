# Testing Editor Contributions

**Notice:** This extension is bundled with Visual Studio Code. It can be disabled but not uninstalled.

Provides the in-editor experience for tests and test results
